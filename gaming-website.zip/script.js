
function launchGame(gameName) {
  alert(`Launching ${gameName}...`);
}

document.getElementById('loginForm').addEventListener('submit', function(e) {
  e.preventDefault();
  const user = document.getElementById('username').value;
  const pass = document.getElementById('password').value;

  if (user === 'player' && pass === '1234') {
    document.getElementById('loginMessage').textContent = `Welcome, ${user}!`;
  } else {
    document.getElementById('loginMessage').textContent = `Login failed.`;
  }
});
